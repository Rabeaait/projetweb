<?php
// Résultats publics des tirages terminés (pas besoin d'être connecté)
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_response(['success' => false, 'error' => 'Méthode non autorisée.'], 405);
}

$conn = get_db();

// On récupère tous les tirages terminés avec leurs statistiques
$res = mysqli_query($conn,
    "SELECT t.id, t.nom, t.annee, t.date_tirage, t.date_ouverture, t.date_cloture, t.nb_gagnants,
            COUNT(p.id)                              AS nb_participants,
            SUM(p.resultat = 'gagnant')              AS nb_gagnants_reels
     FROM tirages t
     LEFT JOIN participations p ON p.tirage_id = t.id
     WHERE t.statut = 'termine'
     GROUP BY t.id
     ORDER BY t.date_tirage DESC"
);

$tirages = [];
while ($row = mysqli_fetch_assoc($res)) $tirages[] = $row;
mysqli_free_result($res);

// Pour chaque tirage, on récupère la liste des gagnants
foreach ($tirages as &$t) {
    $stmt = mysqli_prepare($conn,
        "SELECT u.nom, u.prenom
         FROM utilisateurs u
         JOIN participations p ON p.user_id = u.id
         WHERE p.tirage_id = ? AND p.resultat = 'gagnant'
         ORDER BY u.nom, u.prenom"
    );
    mysqli_stmt_bind_param($stmt, 'i', $t['id']);
    mysqli_stmt_execute($stmt);
    $r = mysqli_stmt_get_result($stmt);
    $gagnants = [];
    while ($w = mysqli_fetch_assoc($r)) $gagnants[] = $w;
    $t['gagnants'] = $gagnants;
    mysqli_stmt_close($stmt);
}
unset($t);

json_response(['success' => true, 'tirages' => $tirages]);
